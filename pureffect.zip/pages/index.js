export default function Home() {
  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Pureffect</h1>
      <p>Καλωσήρθες στο ηλεκτρονικό μας κατάστημα με φυσικά προϊόντα ομορφιάς.</p>
    </main>
  );
}