
# Next.js Starter Template

Αυτό είναι ένα απλό Next.js project έτοιμο για deploy στο Vercel.
