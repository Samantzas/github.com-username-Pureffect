
export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Your Next.js App!</h1>
      <p>Deployed with Vercel</p>
    </div>
  )
}
